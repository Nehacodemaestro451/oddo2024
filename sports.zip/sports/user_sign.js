
// const express = require('express');
// const mongoose = require('mongoose');
// const path = require('path');
// const app = express();

// // Connect to MongoDB
// mongoose.connect('mongodb://127.0.0.1:27017/datastored', {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// })
//   .then(() => { console.log('MongoDB connected successfully'); })
//   .catch((err) => { console.error(err); });

// mongoose.pluralize(null);

// // Define schema and model
// const userSchema = new mongoose.Schema({
//   email: { type: String, required: true },
//   password: { type: String, required: true },
//   phonenumber: { type: String, required: true },
//   areaname: { type: String, required: true }
// });

// const User = mongoose.model('user_sign', userSchema);

// // Middleware to serve static files (like HTML)
// app.use(express.static(__dirname));

// // Serve the HTML form
// app.get('/', (req, res) => {
//   res.sendFile(path.join(__dirname, 'user_sign.html'));
// });

// // Handle form submission (GET method)
// app.get('/process_get', async (req, res) => {
//   try {
//     const userData = new User({
//       email: req.query.email,
//       password: req.query.password,
//       areaname: req.query.areaname,
//       phonenumber: req.query.number
//     });

//     await userData.save();
//     res.send('Record inserted');
//   } catch (err) {
//     console.error(err);
//     res.status(500).send('Server error');
//   }
// });

// // Start the server
// const PORT = 3000;
// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}`);
// });


const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/datastored', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => { console.log('MongoDB connected successfully'); })
  .catch((err) => { console.error(err); });

mongoose.pluralize(null);

// Define schema and model
const userSchema = new mongoose.Schema({
  email: { type: String, required: true },
  password: { type: String, required: true },
  phonenumber: { type: String, required: true },
  areaname: { type: String, required: true }
});

const User = mongoose.model('user_sign', userSchema);

// Middleware to serve static files (like HTML)
app.use(express.static(__dirname));

// Serve the HTML form
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'user_sign.html'));
});

// Handle form submission (GET method)
app.get('/process_get', async (req, res) => {
  try {
    // Check if the email already exists
    const existingUser = await User.findOne({ email: req.query.email });
    if (existingUser) {
      // Redirect to login page if email already exists
      res.redirect('/user_login.html');
    } else {
      // Create new user record if email doesn't exist
      const userData = new User({
        email: req.query.email,
        password: req.query.password,
        areaname: req.query.areaname,
        phonenumber: req.query.number
      });
  
      await userData.save();
      res.send('Record inserted');
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

// Start the server
const PORT = 8000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

