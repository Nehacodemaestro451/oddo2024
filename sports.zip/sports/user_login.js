// Route to fetch and display all users
// app.get('/users', async (req, res) => {
//   try {
//     const users = await User.find({}, 'uname'); // Fetch all users and only return the uname field
//     let responseHtml = '<h1>Users List</h1><ul>';
//     users.forEach(user => {
//       responseHtml += `<li>${user.uname}</li>`;
//     });
//     responseHtml += '</ul>';
//     res.send(responseHtml);
//   } catch (err) {
//     console.error(err);
//     res.status(500).send('Server error');
//   }
// });



// const express = require('express');
// const mongoose = require('mongoose');
// const path = require('path');
// const app = express();

// Connect to MongoDB
// mongoose.connect('mongodb://127.0.0.1:27017/datastored', {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// })
//   .then(() => { console.log('MongoDB connected successfully'); })
//   .catch((err) => { console.error(err); });

// mongoose.pluralize(null);

// Define schema and model
// const userSchema = new mongoose.Schema({
//   email: { type: String, required: true },
//   password: { type: String, required: true }
// });

// const User = mongoose.model('user_login', userSchema);

// Middleware to serve static files (like HTML)
// app.use(express.static(__dirname));

// Serve the HTML form
// app.get('/', (req, res) => {
//   res.sendFile(path.join(__dirname, 'user_login.html'));
// });

// Handle form submission (GET method)
// app.get('/process', async (req, res) => {
//   res.set("content-type","text/html")
  // try {
  //   const userData = new User({
  //     email: req.query.email,
  //     password: req.query.password,
     
  //   });

  //   await userData.save();
  //   res.write('Record inserted in login');
  // } catch (err) {
  //   console.error(err);
  //   res.status(500).write('Server error');
  // }

//   try {
//     const email = req.query.email;
//     const user = await User.findOne({ email: email });

//     if (user) {
//       res.write(`User found: <br>Email: ${user.email} <br>Password: ${user.password}`);
//     } else {
//       res.write("")
//     }
//   } catch (err) {
//     console.error(err);
//     res.status(500).write('Server error');
//   }
// res.send()

// }
// );

// Start the server
// const PORT = 8000;
// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}`);
// });


// const data = await User.find({email : "kevval890@gmail.com"})


const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/datastored', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => { console.log('MongoDB connected successfully'); })
  .catch((err) => { console.error(err); });

mongoose.pluralize(null);

// Define schema and model
const userSchema = new mongoose.Schema({
  email: { type: String, required: true },
  password: { type: String, required: true }
});

const User = mongoose.model('user_login', userSchema);

// Middleware to serve static files (like HTML)
app.use(express.static(__dirname));

// Serve the HTML form
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'user_login.html'));
});

// Handle form submission (GET method)
app.get('/process', async (req, res) => {
  res.set("content-type","text/html");
  try {
    const email = req.query.email;
    const user = await User.findOne({ email: email });

    if (user) {
      res.write(`User found: <br>Email: ${user.email} <br>Password: ${user.password}`);
    } else {
      res.write("User not found. Redirecting to form...");
      res.write('<script>setTimeout(() => { window.location.href = "/"; }, 2000);</script>');
    }
  } catch (err) {
    console.error(err);
    res.status(500).write('Server error');
  }
  res.end();
});

// Start the server
const PORT = 8000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});



